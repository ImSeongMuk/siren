﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestWebApp
{
    public partial class Form1 : Form
    {
        DataTable dataTable;

        public Form1()
        {
            InitializeComponent();
            InitData();
            InitGrid();
            InitChart();
        }

        private void InitChart()
        {
            myChart.Series.Clear();
        }

        private void InitGrid()
        {
            myDataGridView.DataSource = dataTable;
        }

        private void InitData()
        {
            dataTable = new DataTable();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            DialogResult dr = openFileDialog.ShowDialog();
            dataTable = new DataTable();

            if (dr == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(openFileDialog.FileName, Encoding.Default);
                string columns = sr.ReadLine();//한줄씩 읽어 온다//맨 첫번째 줄 
                string[] cols = columns.Split(',');//csv

                dataTable.Columns.Clear();

                for (int i = 0; i < cols.Length; i++)
                {
                    dataTable.Columns.Add(cols[i].Trim(), typeof(string));//colum 추가

                }
                dataTable.Columns.Add("합계");
                dataTable.Columns.Add("평균");


                while (true)
                {
                    string rowsStr = sr.ReadLine();//한줄씩 읽어 온다//첫번째 줄 다음으로 성적 가져옴
                    Console.WriteLine(rowsStr);
                    if (string.IsNullOrEmpty(rowsStr))//없으면 나감
                    {
                        break;
                    }

                   
                    string[]arr = rowsStr.Split(',');
                    
                    
                    myChart.Series.Add(arr[0]);//이름 등록

                    double sum = 0;

                    for (int i = 1; i < arr.Length; i++)
                    {
                        sum = sum + int.Parse(arr[i]);
                        myChart.Series[arr[0]].Points.AddXY(cols[i], arr[i]);//차트 추가
                    }

                    double age = sum / 3;
                    age = Math.Round(age * 100) / 100;
                    dataTable.Rows.Add(arr[0],arr[1], arr[2], arr[3], sum, age);
                    
                    
                }

                
            }
            myDataGridView.DataSource = dataTable;


        }
    }
}
