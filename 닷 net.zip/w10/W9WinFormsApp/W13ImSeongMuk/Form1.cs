﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace W13ImSeongMuk
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //클릭이벤트를 버튼이 아닌곳에도 사용할수있다
            pnlTop.DoubleClick += PnlTop_Click;
            btnInsert.Click += BtnInsert_Click;
            btnUpdate.Click += BtnUpdate_Click;
            btnDelete.Click += BtnDelete_Click;
            myComDataGridView.CellMouseClick += MyComDataGridView_CellMouseClick;
        }

        private void MyComDataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;

            string selectdRowId = myComDataGridView.Rows[rowIndex].Cells[0].Value.ToString();
            //선택된 로우(가로)에서 첫번째(0) cell의 값은 id(키값)이다. 

            Console.WriteLine(selectdRowId);
            StringBuilder sb = new StringBuilder();
            sb.Append(" select * from myCompany1 ");
            sb.Append(" where ");
            sb.Append(" id= '"); sb.Append(selectdRowId); sb.Append("' ");
            String sql = sb.ToString();

            MySqlConnection conn = new MySqlConnection(mySqlConnstr);
            conn.Open();
            MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);

            if (ds.Tables["myOne"] != null) {//임시 저장을 하기위한 Datatable 이 null이 아닐때 초기화
                ds.Tables["myOne"].Clear();
            }

            //방법1
            adpt.Fill(ds, "myOne");
            string id = ds.Tables["myOne"].Rows[0]["id"].ToString();
            string name = ds.Tables["myOne"].Rows[0]["name"].ToString();
            string email = ds.Tables["myOne"].Rows[0][2].ToString();
            string dept = ds.Tables["myOne"].Rows[0][3].ToString();
            string job = ds.Tables["myOne"].Rows[0]["job"].ToString();
            string level = ds.Tables["myOne"].Rows[0]["level"].ToString();
            string fla_type = ds.Tables["myOne"].Rows[0]["fla_type"].ToString();
            string fla_value = ds.Tables["myOne"].Rows[0]["fla_value"].ToString();
            string flb_type = ds.Tables["myOne"].Rows[0]["flb_type"].ToString();
            string flb_value = ds.Tables["myOne"].Rows[0]["flb_value"].ToString();
            string score = ds.Tables["myOne"].Rows[0]["score"].ToString();
            string salary = ds.Tables["myOne"].Rows[0]["salary"].ToString();

            //방법2
            string id2 = myComDataGridView.Rows[rowIndex].Cells[0].Value.ToString();

            //2가지 방법이 있다 방법2가 좀더 편하다.
            /*           
            string name = myComDataGridView.Rows[rowIndex][1].ToString();
 
             */


            txtID.Text = id2;
            txtName.Text = name;
            txtEmail.Text = email;
            txtDept.Text = dept;
            txtJob.Text = job;
            txtLeval.Text = level;
            txtFlaType.Text = fla_type;
            txtFlaValue.Text = fla_value;
            txtFlbType.Text = flb_type;
            txtFlbValue.Text = flb_value;
            txtScore.Text = score;
            txtSalary.Text = salary;
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                ds = new DataSet();
                //접속
                MySqlConnection conn = new MySqlConnection(mySqlConnstr);
                conn.Open();
                //쿼리문
                StringBuilder sb = new StringBuilder();
                sb.Append(" update myCompany1 ");
                sb.Append(" set ");
                sb.Append(" name = '"); sb.Append(txtName.Text); sb.Append("', ");
                sb.Append(" email = '"); sb.Append(txtEmail.Text); sb.Append("', ");
                sb.Append(" dept = '"); sb.Append(txtDept.Text); sb.Append("', ");
                sb.Append(" job = '"); sb.Append(txtJob.Text); sb.Append("', ");
                sb.Append(" level = '"); sb.Append(txtLeval.Text); sb.Append("', ");
                sb.Append(" fla_type = '"); sb.Append(txtFlaType.Text); sb.Append("', ");
                sb.Append(" fla_value = '"); sb.Append(txtFlaValue.Text); sb.Append("', ");
                sb.Append(" flb_type = '"); sb.Append(txtFlbType.Text); sb.Append("', ");
                sb.Append(" flb_value = '"); sb.Append(txtFlbValue.Text); sb.Append("', ");
                sb.Append(" score = '"); sb.Append(txtScore.Text); sb.Append("', ");
                sb.Append(" salary = '"); sb.Append(txtSalary.Text); sb.Append("' ");
                sb.Append(" where ");
                sb.Append(" id = '"); sb.Append(txtID.Text); sb.Append("' ");
                //추가
                string sql = sb.ToString();

                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "myCompany1");
                myComDataGridView.DataSource = ds.Tables["myCompany1"];
                Serach();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ds = new DataSet();
                //접속
                MySqlConnection conn = new MySqlConnection(mySqlConnstr);

                conn.Open();
                //쿼리문
                StringBuilder sb = new StringBuilder();
                sb.Append(" delete from myCompany1 ");
                sb.Append(" where ");
                sb.Append(" id = '"); sb.Append(txtID.Text); sb.Append("' ");
                //추가
                string sql = sb.ToString();

                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);

                adpt.Fill(ds, "myCompany1");

                myComDataGridView.DataSource = ds.Tables["myCompany1"];
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {

            try
            {
                ds = new DataSet();
                //접속
                MySqlConnection conn = new MySqlConnection(mySqlConnstr);
                conn.Open();
                //쿼리문
                StringBuilder sb = new StringBuilder();
                sb.Append(" insert into myCompany1 ");
                sb.Append(" values( ");
                sb.Append(" '"); sb.Append(txtID.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtName.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtEmail.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtDept.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtJob.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtLeval.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtFlaType.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtFlaValue.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtFlbType.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtFlbValue.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtScore.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtSalary.Text); sb.Append("' ");
                sb.Append(" )");
                //추가
                string sql = sb.ToString();

                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "myCompany1");
                myComDataGridView.DataSource = ds.Tables["myCompany1"];
                Serach();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void PnlTop_Click(object sender, EventArgs e)
        {
            try
            {
                //드레그 하고 우클릭을 하면 빠른작업 및 리펙터링이 있다
                //리펙터링을 사용하면 빠르게 드레그한 내용을 메서드화 시켜준다 그다음 사용하면 개꿀
                Serach();

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.ToString());
            }
            //throw new NotImplementedException();

        }

        private static string mySqlConnstr
            = "Server=61.84.24.251;Database=myClassInc;Uid=classuser1;Pwd=cs1234!;Charset=utf8";
        DataSet ds;

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                //데이터 공간 생성
                Serach();

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.ToString());
            }
        }

        private void Serach()
        {
            ds = new DataSet();

            //접속
            MySqlConnection conn = new MySqlConnection(mySqlConnstr);
            conn.Open();

            //쿼리문
            StringBuilder sb = new StringBuilder();
            sb.Append(" select * from myCompany1");

            string sql = sb.ToString();

            MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
            adpt.Fill(ds, "myCompany1");
            myComDataGridView.DataSource = ds.Tables["myCompany1"];
        }
    }
}
