﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Roslyn.Compilers;
using Roslyn.Compilers.CSharp;
using Roslyn.Scripting.CSharp;

namespace windowFormFuntion
{
    public partial class TestFile : Form
    {
        public TestFile()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            var engine = new ScriptEngine();
            string expression = txtString.Text;
            expression = expression.Replace("y=", "");//Replace 는 문자열을 변경해준다
            expression = expression.Replace("x", txtX.Text);
            expression = expression.Replace(" ", "");
            string result = engine.Execute(expression).ToString();
            txtY.Text = result;
        }

    }
}
