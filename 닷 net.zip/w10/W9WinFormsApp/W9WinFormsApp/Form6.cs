﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using W9ClassLib;

namespace W9WinFormsApp
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
            Initcbo();
            myChart.Series.Clear();
        }

        private void Initcbo()
        {
            cboChartType.Items.Add("Column");
            cboChartType.Items.Add("Doughnut");
            cboChartType.Items.Add("Funnel");
            cboChartType.Items.Add("Bubble");
            cboChartType.Items.Add("Pyramid");
            cboChartType.Items.Add("Spline");
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            myChart.Series.Clear();//초기화
            Series s1 = new Series("인구");//그래프 이름
            String[] xValue = { "서울","대전","전주" };//x축 값
            int[] yValue1 = { 10000, 3000, 2000 };//y축 값

            if (cboChartType.Text.Equals("Funnel")) 
                s1.ChartType = SeriesChartType.Funnel;
            else if(cboChartType.Text.Equals("Bubble"))
                s1.ChartType = SeriesChartType.Bubble;
            else if (cboChartType.Text.Equals("Pyramid"))
                s1.ChartType = SeriesChartType.Pyramid;
            else if (cboChartType.Text.Equals("Spline"))
                s1.ChartType = SeriesChartType.Spline;
            else if (cboChartType.Text.Equals("Column"))
                s1.ChartType = SeriesChartType.Column;
            else if (cboChartType.Text.Equals("Doughnut"))
                s1.ChartType = SeriesChartType.Doughnut;
            else
                s1.ChartType = SeriesChartType.Point;

            s1.Points.DataBindXY(xValue, yValue1);
            myChart.Series.Add(s1);

            //Series s2 = new Series("남자");//그래프 이름
            //int[] yValue2 = { 5000, 2000, 500 };//y축 값
            //s2.ChartType = SeriesChartType.Column;
            //s2.Points.DataBindXY(xValue, yValue2);
            //myChart.Series.Add(s2);

            //Series s3 = new Series("여자");//그래프 이름
            //int[] yValue3 = { 5000, 1000, 1500 };//y축 값
            //s3.ChartType = SeriesChartType.Column;
            //s3.Points.DataBindXY(xValue, yValue3);
            //myChart.Series.Add(s3);

        }

        private void btnDraw2_Click(object sender, EventArgs e)
        {
            myChart.Series.Clear();//초기화
            Series s1 = new Series("서울");//그래프 이름
            String[] xValue = { "인구", "남자", "여자" };//x축 값
            int[] yValue1 = { 10000, 5000, 5000 };//y축 값
            s1.ChartType = SeriesChartType.Column;
            s1.Points.DataBindXY(xValue, yValue1);
            myChart.Series.Add(s1);

            Series s2 = new Series("대전");//그래프 이름
            int[] yValue2 = { 3000, 2000, 1000 };//y축 값
            s2.ChartType = SeriesChartType.Column;
            s2.Points.DataBindXY(xValue, yValue2);
            myChart.Series.Add(s2);

            Series s3 = new Series("전주");//그래프 이름
            int[] yValue3 = { 2000, 500, 1500 };//y축 값
            s3.ChartType = SeriesChartType.Column;
            s3.Points.DataBindXY(xValue, yValue3);
            myChart.Series.Add(s3);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            myChart.Series.Clear();//초기화
            DataGenClass dataGenClass = new DataGenClass();
            DataTable dataTable = dataGenClass.GetDataTableSimple();

            Series[] SeriesArr = new Series[dataTable.Columns.Count];
            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                SeriesArr[i] = new Series(dataTable.Columns[i].ToString());
                SeriesArr[i].ChartType = SeriesChartType.Radar;
                for (int j = 0; j < dataTable.Rows.Count; j++)
                {
                    SeriesArr[i].Points.AddY(dataTable.Rows[j][i].ToString());
                }
            }

            for (int i = 0; i < SeriesArr.Length; i++)
            {
                // 무슨 코드를 넣어야 할 까?
                myChart.Series.Add(SeriesArr[i]);
            }

        }
    }
}
