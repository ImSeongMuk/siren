﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql;
using MySql.Data.MySqlClient;

namespace W12ImSeongMuk
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static string mySqlConnstr 
            = "Server=61.84.24.251;Database=myClassInc;Uid=classuser1;Pwd=cs1234!;Charset=utf8";
        DataSet ds;


        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                //데이터 공간 생성
                ds = new DataSet();
                //접속
                MySqlConnection conn = new MySqlConnection(mySqlConnstr);

                conn.Open();
                //쿼리문
                StringBuilder sb = new StringBuilder();
                sb.Append("select ");
                sb.Append("id as 'ID'");
                //추가
                if (cbName.Checked) {
                    sb.Append(" ,name as '이름' ");
                }
                if (cbEmail.Checked)
                {
                    sb.Append(" ,email as 'E-Mail' ");
                }
                if (cbDept.Checked)
                {
                    sb.Append(" ,dept as '부서' ");
                }
                if (cbJob.Checked)
                {
                    sb.Append(" ,job as '직군' ");
                }
                if (cbLevel.Checked)
                {
                    sb.Append(" ,level as '직위' ");
                }
                if (cbSalary.Checked)
                {
                    sb.Append(" ,salary as '연봉' ");
                }
                sb.Append(" from myCompany1 ");
                sb.Append(" where 1=1 ");
                if (!(txtCondition.Text == "")) {
                    sb.Append(" and "+txtCondition.Text);
                }
                string sql = sb.ToString();

                MySqlDataAdapter adpt = new MySqlDataAdapter(sql,conn);

                adpt.Fill(ds, "myCompany1");

                myComDataGridView.DataSource = ds.Tables[0];
                
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
