﻿namespace W12ImSeongMuk
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.myComDataGridView = new System.Windows.Forms.DataGridView();
            this.btnSearch = new System.Windows.Forms.Button();
            this.cbName = new System.Windows.Forms.CheckBox();
            this.cbEmail = new System.Windows.Forms.CheckBox();
            this.cbDept = new System.Windows.Forms.CheckBox();
            this.cbJob = new System.Windows.Forms.CheckBox();
            this.cbLevel = new System.Windows.Forms.CheckBox();
            this.cbSalary = new System.Windows.Forms.CheckBox();
            this.txtCondition = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.myComDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtCondition);
            this.panel1.Controls.Add(this.cbSalary);
            this.panel1.Controls.Add(this.cbLevel);
            this.panel1.Controls.Add(this.cbJob);
            this.panel1.Controls.Add(this.cbDept);
            this.panel1.Controls.Add(this.cbEmail);
            this.panel1.Controls.Add(this.cbName);
            this.panel1.Controls.Add(this.btnSearch);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(771, 55);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.myComDataGridView);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 55);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(771, 453);
            this.panel2.TabIndex = 1;
            // 
            // myComDataGridView
            // 
            this.myComDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.myComDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.myComDataGridView.Location = new System.Drawing.Point(0, 0);
            this.myComDataGridView.Name = "myComDataGridView";
            this.myComDataGridView.RowTemplate.Height = 23;
            this.myComDataGridView.Size = new System.Drawing.Size(771, 453);
            this.myComDataGridView.TabIndex = 0;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(684, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 0;
            this.btnSearch.Text = "db가져오기";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // cbName
            // 
            this.cbName.AutoSize = true;
            this.cbName.Location = new System.Drawing.Point(13, 19);
            this.cbName.Name = "cbName";
            this.cbName.Size = new System.Drawing.Size(58, 16);
            this.cbName.TabIndex = 1;
            this.cbName.Text = "Name";
            this.cbName.UseVisualStyleBackColor = true;
            // 
            // cbEmail
            // 
            this.cbEmail.AutoSize = true;
            this.cbEmail.Location = new System.Drawing.Point(77, 19);
            this.cbEmail.Name = "cbEmail";
            this.cbEmail.Size = new System.Drawing.Size(56, 16);
            this.cbEmail.TabIndex = 2;
            this.cbEmail.Text = "EMail";
            this.cbEmail.UseVisualStyleBackColor = true;
            // 
            // cbDept
            // 
            this.cbDept.AutoSize = true;
            this.cbDept.Location = new System.Drawing.Point(139, 19);
            this.cbDept.Name = "cbDept";
            this.cbDept.Size = new System.Drawing.Size(49, 16);
            this.cbDept.TabIndex = 3;
            this.cbDept.Text = "Dept";
            this.cbDept.UseVisualStyleBackColor = true;
            // 
            // cbJob
            // 
            this.cbJob.AutoSize = true;
            this.cbJob.Location = new System.Drawing.Point(201, 19);
            this.cbJob.Name = "cbJob";
            this.cbJob.Size = new System.Drawing.Size(44, 16);
            this.cbJob.TabIndex = 4;
            this.cbJob.Text = "Job";
            this.cbJob.UseVisualStyleBackColor = true;
            // 
            // cbLevel
            // 
            this.cbLevel.AutoSize = true;
            this.cbLevel.Location = new System.Drawing.Point(251, 19);
            this.cbLevel.Name = "cbLevel";
            this.cbLevel.Size = new System.Drawing.Size(54, 16);
            this.cbLevel.TabIndex = 5;
            this.cbLevel.Text = "Level";
            this.cbLevel.UseVisualStyleBackColor = true;
            // 
            // cbSalary
            // 
            this.cbSalary.AutoSize = true;
            this.cbSalary.Location = new System.Drawing.Point(311, 19);
            this.cbSalary.Name = "cbSalary";
            this.cbSalary.Size = new System.Drawing.Size(60, 16);
            this.cbSalary.TabIndex = 6;
            this.cbSalary.Text = "Salary";
            this.cbSalary.UseVisualStyleBackColor = true;
            this.cbSalary.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // txtCondition
            // 
            this.txtCondition.Location = new System.Drawing.Point(420, 17);
            this.txtCondition.Name = "txtCondition";
            this.txtCondition.Size = new System.Drawing.Size(237, 21);
            this.txtCondition.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 508);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.myComDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView myComDataGridView;
        private System.Windows.Forms.CheckBox cbName;
        private System.Windows.Forms.CheckBox cbSalary;
        private System.Windows.Forms.CheckBox cbLevel;
        private System.Windows.Forms.CheckBox cbJob;
        private System.Windows.Forms.CheckBox cbDept;
        private System.Windows.Forms.CheckBox cbEmail;
        private System.Windows.Forms.TextBox txtCondition;
    }
}

