﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using W9ClassLib;

namespace W9WinFormsApp
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        DataTable dataTable;

        

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            DialogResult dr = openFileDialog.ShowDialog();
            dataTable = new DataTable(); 
            if (dr==DialogResult.OK)
            {
                StreamReader sr = new StreamReader(openFileDialog.FileName, Encoding.Default);
                string columns = sr.ReadLine();//한줄씩 읽어 온다
                string[] cols = columns.Split(',');//csv
                
                dataTable.Columns.Clear();
                for (int i = 0; i < cols.Length; i++)
                {
                    dataTable.Columns.Add(cols[i].Trim(), typeof(double));//더블형의 타입으로 더하기
                }              

                while (true)
                {
                    string rowsStr = sr.ReadLine();
                    Console.WriteLine(rowsStr);
                    if (string.IsNullOrEmpty(rowsStr))
                    {
                        break;
                    }

                    string[] arr = rowsStr.Split(',');
                    dataTable.Rows.Add(arr);
                }
            }
            myDataGridView.DataSource = dataTable;

        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            String inputText = cboFunc.Text + "(" + txtParam.Text + ")";
            String result = dataTable.Compute(inputText, "").ToString();
            MessageBox.Show(result);
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {

            dataTable = new DataTable();
            DataGenClass datagen = new DataGenClass();
            dataTable = datagen.GetDataTableSimple();
            myDataGridView.DataSource = dataTable;
        }
    }
}
