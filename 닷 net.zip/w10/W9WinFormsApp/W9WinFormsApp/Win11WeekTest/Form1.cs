﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using W9ClassLib;

namespace Win11WeekTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitData();
            InitGrid();
            InitChart();
            
        }

        DataTable dataTable;

        private void InitData()
        {
            dataTable = new DataTable();
            dataTable.Columns.Add("Param1", typeof(double));
            dataTable.Columns.Add("Param2", typeof(double));
            dataTable.Columns.Add("Param3", typeof(double));
            dataTable.Columns.Add("Param4", typeof(double));
        }

        private void InitChart()
        {
            myChart.Series.Clear();
            myChart.Series.Add("Param1");
            myChart.Series.Add("Param2");
            myChart.Series.Add("Param3");
            myChart.Series.Add("Param4");
            myChart.Series["Param1"].ChartType = SeriesChartType.FastPoint;
            myChart.Series["Param2"].ChartType = SeriesChartType.FastPoint;
            myChart.Series["Param3"].ChartType = SeriesChartType.FastPoint;
            myChart.Series["Param4"].ChartType = SeriesChartType.FastPoint;

        }

        private void InitGrid()
        {
            myDataGridView.DataSource = dataTable;
        }

        

        

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddDataGrid(txtParam1.Text, txtParam2.Text, txtParam3.Text, txtParam4.Text);
            AddDataChart(txtParam1.Text, txtParam2.Text, txtParam3.Text, txtParam4.Text);
            
        }

        private void AddDataGrid(string text1, string text2, string text3, string text4)
        {
            dataTable.Rows.Add(text1, text2, text3, text4);
        }

        private void AddDataChart(string text1, string text2, string text3, string text4)
        {
            myChart.Series["Param1"].Points.AddY(text1);
            myChart.Series["Param2"].Points.AddY(text2);
            myChart.Series["Param3"].Points.AddY(text3);
            myChart.Series["Param4"].Points.AddY(text4);
        }

        private void btnAddRdn_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            AddDataGrid(random.NextDouble().ToString(),
                        random.NextDouble().ToString(),
                        random.NextDouble().ToString(),
                        random.NextDouble().ToString());

            AddDataChart(random.NextDouble().ToString(),
                         random.NextDouble().ToString(),
                         random.NextDouble().ToString(),
                         random.NextDouble().ToString());
        }
    }
}
