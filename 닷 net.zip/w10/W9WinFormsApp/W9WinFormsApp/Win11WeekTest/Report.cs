﻿using Roslyn.Scripting.CSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using W9ClassLib;

namespace Win11WeekTest
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
            InitData();
            InitGrid();
            InitChart();
            
        }

        DataTable dataTable;

        private void InitData()
        {
            dataTable = new DataTable();
            dataTable.Columns.Add("이름");
            dataTable.Columns.Add("영어", typeof(double));
            dataTable.Columns.Add("수학", typeof(double));
            dataTable.Columns.Add("과학", typeof(double));
            dataTable.Columns.Add("총점", typeof(double));
            dataTable.Columns.Add("평균", typeof(double));
        }

        private void InitChart()
        {
            myChart.Series.Clear();
        }

        private void InitGrid()
        {
            myDataGridView.DataSource = dataTable;
        }

        

        

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddDataGrid(txtName.Text, txtEng.Text, txtMath.Text, txtSience.Text);
            AddDataChart(txtName.Text, txtEng.Text, txtMath.Text, txtSience.Text);
            
        }

        private void AddDataGrid(string text1, string text2, string text3, string text4)
        {
            var engine = new ScriptEngine();
            string sum = engine.Execute("(" + text2 + "+" + text3 + "+" + text4 + ")").ToString();
            string avg = engine.Execute("(" + text2 + "+" + text3 + "+" + text4 + ")/3").ToString();
            dataTable.Rows.Add(text1, text2, text3, text4,sum,avg);
        }

        private void AddDataChart(string name, string text2, string text3, string text4)
        {
            myChart.Series.Add(name);
            myChart.Series[name].Points.AddXY("영어", text2);
            myChart.Series[name].Points.AddXY("수학", text3);
            myChart.Series[name].Points.AddXY("과학", text4);
        }

        int i = 1;
        private void btnAddRdn_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            Double r1 = random.Next() % 100;
            Double r2 = random.Next() % 100;
            Double r3 = random.Next() % 100;


            AddDataGrid("사용자"+i, r1.ToString(), r2.ToString(), r3.ToString());

            AddDataChart("사용자" + i, r1.ToString(), r2.ToString(), r3.ToString());
            i++;
        }
    }
}
