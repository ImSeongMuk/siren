﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W14ImSeongMuk
{
    public partial class Conpany : Form
    {
        public Conpany()
        {
            InitializeComponent();
            btnSerch.Click += BtnSerch_Click;
            btnInsert.Click += BtnInsert_Click;
            btnUpdate.Click += BtnUpdate_Click;
            btnDelete.Click += BtnDelete_Click;
            myComDataGridView.CellMouseClick += MyComDataGridView_CellMouseClick;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ds = new DataSet();
                //접속
                MySqlConnection conn = new MySqlConnection(mySqlConnstr);

                conn.Open();
                //쿼리문
                StringBuilder sb = new StringBuilder();
                sb.Append(" delete from myCompany1 ");
                sb.Append(" where ");
                sb.Append(" id = '"); sb.Append(txtId.Text); sb.Append("' ");
                //추가

                string sql = sb.ToString();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();


                sb.Clear();
                sb.Append(" delete from myCompany2 ");
                sb.Append(" where ");
                sb.Append(" id = '"); sb.Append(txtId.Text); sb.Append("' ");

                sql = sb.ToString();
                cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();

                search();

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {

            ds = new DataSet();
            //접속
            MySqlConnection conn = new MySqlConnection(mySqlConnstr);
            conn.Open();
            //쿼리문
            StringBuilder sb = new StringBuilder();
            sb.Append(" update myCompany1 ");
            sb.Append(" set ");
            sb.Append(" name = '"); sb.Append(txtName.Text); sb.Append("', ");
            sb.Append(" email = '"); sb.Append(txtEmail.Text); sb.Append("', ");
            sb.Append(" dept = '"); sb.Append(txtDept.Text); sb.Append("', ");
            sb.Append(" job = '"); sb.Append(txtJob.Text); sb.Append("', ");
            sb.Append(" level = '"); sb.Append(txtLevel.Text); sb.Append("', ");
            sb.Append(" fla_type = '"); sb.Append(txtFla_type.Text); sb.Append("', ");
            sb.Append(" fla_value = '"); sb.Append(txtFla_value.Text); sb.Append("', ");
            sb.Append(" flb_type = '"); sb.Append(txtFlb_type.Text); sb.Append("', ");
            sb.Append(" flb_value = '"); sb.Append(txtFlb_value.Text); sb.Append("', ");
            sb.Append(" score = '"); sb.Append(txtScore.Text); sb.Append("', ");
            sb.Append(" salary = '"); sb.Append(txtSalary.Text); sb.Append("' ");
            sb.Append(" where ");
            sb.Append(" id = '"); sb.Append(txtId.Text); sb.Append("' ");
            //추가
            string sql = sb.ToString();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            cmd.ExecuteNonQuery();


            sb.Clear();
            sb.Append(" update myCompany2 ");
            sb.Append(" set ");
            sb.Append(" password = '"); sb.Append(txtPassword.Text); sb.Append("', ");
            sb.Append(" phone = '"); sb.Append(txtPhone.Text); sb.Append("' ");
            sb.Append(" where ");
            sb.Append(" id = '"); sb.Append(txtId.Text); sb.Append("' ");
            sql = sb.ToString();
            cmd = new MySqlCommand(sql, conn);
            cmd.ExecuteNonQuery();

            search();
        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {
            if (!Validation()) {
                return;
            }
            

            try
            {
                ds = new DataSet();
                //접속
                MySqlConnection conn = new MySqlConnection(mySqlConnstr);
                conn.Open();
                //쿼리문
                StringBuilder sb = new StringBuilder();
                sb.Append(" insert into myCompany1 ");
                sb.Append(" values( ");
                sb.Append(" '"); sb.Append(txtId.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtName.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtEmail.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtDept.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtJob.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtLevel.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtFla_type.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtFla_value.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtFlb_type.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtFlb_value.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtScore.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtSalary.Text); sb.Append("' ");
                sb.Append(" )");
                //추가
                string sql = sb.ToString();

                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();

                sb.Clear();

                sb.Append(" insert into myCompany2 ");
                sb.Append(" values( ");
                sb.Append(" '"); sb.Append(txtId.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtPassword.Text); sb.Append("', ");
                sb.Append(" '"); sb.Append(txtPhone.Text); sb.Append("' ");
                sb.Append(" )");
                sql = sb.ToString();

                cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();

                search();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private Boolean Validation()
        {
           
            string ruleMail = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,64}";
            Regex regexMail = new Regex(ruleMail);
            if (!regexMail.IsMatch(txtEmail.Text))
            {
                MessageBox.Show("이메일 형식이 틀렸습니다.");
                return false;
            }

            string rulePh = @"^\d{3}-\d{3,4}-\d{4}$";
            Regex regexPh = new Regex(rulePh);
            if (!regexPh.IsMatch(txtPhone.Text))
            {
                MessageBox.Show("전화번호 형식이 틀렸습니다.");
                return false;
            }

            return true;

        }

        private void MyComDataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;

            string selectdRowId = myComDataGridView.Rows[rowIndex].Cells[0].Value.ToString();
            //선택된 로우(가로)에서 첫번째(0) cell의 값은 id(키값)이다. 

            Console.WriteLine(selectdRowId);
            StringBuilder sb = new StringBuilder();
            sb.Append(" select a.id as id, a.name as name, a.email as email, a.dept as dept," +
                    " a.job as job, a.level as level, a.fla_type as fla_type, a.fla_value as fla_value, a.flb_type as flb_type, a.flb_value as flb_value,a.score as score,a.salary as salary,b.password as password,b.phone as phone" +
                    " from myCompany1 a, myCompany2 b where a.id = b.id ");
            sb.Append(" and ");
            sb.Append(" a.id= '"); sb.Append(selectdRowId); sb.Append("' ");
            String sql = sb.ToString();

            MySqlConnection conn = new MySqlConnection(mySqlConnstr);
            conn.Open();
            MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);

            if (ds.Tables["myOne"] != null)
            {//임시 저장을 하기위한 Datatable 이 null이 아닐때 초기화
                ds.Tables["myOne"].Clear();
            }

            //방법1
            adpt.Fill(ds, "myOne");
            string id = ds.Tables["myOne"].Rows[0]["id"].ToString();
            string name = ds.Tables["myOne"].Rows[0]["name"].ToString();
            string email = ds.Tables["myOne"].Rows[0][2].ToString();
            string dept = ds.Tables["myOne"].Rows[0][3].ToString();
            string job = ds.Tables["myOne"].Rows[0]["job"].ToString();
            string level = ds.Tables["myOne"].Rows[0]["level"].ToString();
            string fla_type = ds.Tables["myOne"].Rows[0]["fla_type"].ToString();
            string fla_value = ds.Tables["myOne"].Rows[0]["fla_value"].ToString();
            string flb_type = ds.Tables["myOne"].Rows[0]["flb_type"].ToString();
            string flb_value = ds.Tables["myOne"].Rows[0]["flb_value"].ToString();
            string score = ds.Tables["myOne"].Rows[0]["score"].ToString();
            string salary = ds.Tables["myOne"].Rows[0]["salary"].ToString();
            string password = ds.Tables["myOne"].Rows[0]["password"].ToString();
            string phone = ds.Tables["myOne"].Rows[0]["phone"].ToString();

            //방법2
            string id2 = myComDataGridView.Rows[rowIndex].Cells[0].Value.ToString();

            //2가지 방법이 있다 방법2가 좀더 편하다.
            /*           
            string name = myComDataGridView.Rows[rowIndex][1].ToString();
 
             */


            txtId.Text = id2;
            txtName.Text = name;
            txtEmail.Text = email;
            txtDept.Text = dept;
            txtJob.Text = job;
            txtLevel.Text = level;
            txtFla_type.Text = fla_type;
            txtFla_value.Text = fla_value;
            txtFlb_type.Text = flb_type;
            txtFlb_value.Text = flb_value;
            txtScore.Text = score;
            txtSalary.Text = salary;
            txtPassword.Text = password;
            txtPhone.Text = phone;
        }

        private static string mySqlConnstr
            = "Server=61.84.24.251;Database=myClassInc;Uid=classuser1;Pwd=cs1234!;Charset=utf8";
        DataSet ds;

        private void BtnSerch_Click(object sender, EventArgs e)
        {
            try
            {
                search();

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.ToString());
            }
        }

        private void search()
        {
            //데이터 공간 생성
            ds = new DataSet();

            //접속
            MySqlConnection conn = new MySqlConnection(mySqlConnstr);
            conn.Open();

            //쿼리문
            StringBuilder sb = new StringBuilder();
            sb.Append(" select a.id as id, a.name as name, a.email as email, a.dept as dept," +
                " a.job as job, a.level as level, a.fla_type as fla_type, a.fla_value as fla_value, a.flb_type as flb_type, a.flb_value as flb_value,a.score as score,a.salary as salary,b.password as password,b.phone as phone" +
                " from myCompany1 a, myCompany2 b where a.id = b.id");

            string sql = sb.ToString();

            MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
            adpt.Fill(ds, "myCompany1");
            myComDataGridView.DataSource = ds.Tables["myCompany1"];
        }
    }
}
