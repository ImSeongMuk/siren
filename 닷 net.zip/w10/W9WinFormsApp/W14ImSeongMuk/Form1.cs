﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W14ImSeongMuk
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            btnRex.Click += BtnRex_Click;
        }

        private void BtnRex_Click(object sender, EventArgs e)
        {
            //Regex regex = new Regex(@"^01[01678]-[0-9]{4}-[0-9]{4}$");

            string rule = txtRule.Text;
            string test = txtTest.Text;
            Regex rex = new Regex(rule);

            if (rex.IsMatch(test))
            {
                MessageBox.Show("매칭됨");
            }else {
                MessageBox.Show("매칭 놉");
            }

        }
    }
}
