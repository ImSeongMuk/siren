#File name: my_first_module.py
PI = 3.14  
def sq_area(a):
    return a**2
def ci_area(r):
    return PI * r**2
