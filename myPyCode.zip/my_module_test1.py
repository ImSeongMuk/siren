def func(a):
    print("입력숫자:",a)
func(3)
