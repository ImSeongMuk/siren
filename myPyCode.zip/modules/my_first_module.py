#File name: my_first_module.py
    
def my_function():
    print("안녕안녕안녕")
