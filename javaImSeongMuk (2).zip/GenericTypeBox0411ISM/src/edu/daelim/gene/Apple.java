package edu.daelim.gene;

public class Apple {
	
}
