package edu.daelim.genericmultitype;

public class GenericMulti {
	
	public static void main(String[] args) {
		//Product <Tv, String> product1 = new Product<Tv, String>();
		Product <Tv, String> product1 = new Product<>();//�ٿ��� ��밡��
		product1.setKind(new Tv());
		product1.setmodel("����Ʈ ");
		
		Tv tv1 = product1.getKind();
		String tvModel = product1.getModel();
		
		Product <Car, String> product2 = new Product<Car, String>();
		product2.setKind(new Car());
		product2.setmodel("���");
		
		Car car1 = product2.getKind();
		String carModel = product2.getModel();
		
		System.out.println(tv1);
		System.out.println(tvModel);
		System.out.println(car1);
		System.out.println(carModel);
	}

}
