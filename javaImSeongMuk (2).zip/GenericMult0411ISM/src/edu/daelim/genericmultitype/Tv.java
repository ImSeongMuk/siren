package edu.daelim.genericmultitype;

public class Tv{
	
}
