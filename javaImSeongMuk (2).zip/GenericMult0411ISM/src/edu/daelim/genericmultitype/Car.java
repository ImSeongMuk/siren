package edu.daelim.genericmultitype;

public class Car {

}
