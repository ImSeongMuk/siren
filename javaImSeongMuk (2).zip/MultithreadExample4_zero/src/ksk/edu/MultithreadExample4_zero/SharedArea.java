package ksk.edu.MultithreadExample4_zero;
class SharedArea {
    double result; 
    boolean isReady = false; //(���1)
}
