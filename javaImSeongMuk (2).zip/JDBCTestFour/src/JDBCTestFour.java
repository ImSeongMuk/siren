import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCTestFour {

	public static void main(String[] args) {
		Connection conn = null ;
		Statement  stmt =  null ;
		
		try{
			Class.forName("com.mysql.cj.jdbc.Driver"); // MySQL ����̹� �ε�
			conn = DriverManager.getConnection("jdbc:mysql://localhost:1443/malldb?allowPublicKeyRetrieval=false&useSSL=false&serverTimezone=Asia/Seoul", 
					//"root","comso1234"); // JDBC ����
					"root","daelim7!"); // JDBC ����
			System.out.println("���� ����");
			
			stmt = 
		(Statement)conn.createStatement();
			ResultSet  rs = stmt.executeQuery(
		"select code, name,price,maker from goodsinfo") ;
					
//			ResultSet  rs = stmt.executeQuery(
//  "select code, name,price,maker from goodsinfo where name = '" + toLatin(args[0]) + "';" ) ;   
			
			System.out.println(
				"��ǰ�ڵ�  \t��ǰ��  \t\t\t ����  ������") ;
			System.out.println(
				"-----------------------------------------------------");
			while(rs.next())
			{
				String code = rs.getString("code");
				String name =rs.getString("name");
				int price =rs.getInt("price");
				String maker =rs.getString("maker");
				System.out.printf("%8s  %s  \t %12d %s\n", 
						code, name,	price, maker);
						//code, toUnicode(name),
						//price, toUnicode(maker));
			}			
		}
		catch(ClassNotFoundException  e)
		{
			System.out.println(
				"Driver Ŭ���� ã�� ����");
		}
		catch(SQLException  se)
		{
			System.out.println(
					se.getMessage() );
		}
		finally{
			try{
				stmt.close();
			}
			catch(Exception  e)
			{	}
			try
			{
				conn.close();
			}
			catch(Exception   e)
			{
				System.out.println(e.getMessage());
			}
		}//end of  finally block
	}//end of main()
	
//	private static String toLatin(String str)
//	{
//		try{
//			byte[]  b = str.getBytes();
//			return new String(b, "ISO-8859-1");
//		}
//		catch(java.io.
//		  UnsupportedEncodingException e)
//		{
//			System.out.println(e.getMessage());
//			return null ;
//		}
//		
//	}
//	
//	private static String toUnicode(String  str)
//	{
//		try{
//			byte[]  b = 
//					str.getBytes("ISO-8859-1");
//			return new String(b);
//		}
//		catch(java.io.UnsupportedEncodingException e)
//		{
//			System.out.println(e.getMessage());
//			return null ;
//		}
//	}
}
