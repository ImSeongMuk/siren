
public class ChildProductAndStorageExample {
	public static void main(String[] args) {
		ChildProduct<Tv, String, String> product = 
				new ChildProduct<>();
		product.setKind(new Tv());
		product.setModel("SmartTV");
		product.setCompany("Samsung");
		
		System.out.printf("�𵨸�=%s\n", 
				product.getModel() ) ;
		System.out.printf("ȸ���=%s\n",
				product.getCompany());
		
		Storage<Tv> storage = 
				new StorageImpl<Tv>(100);
		storage.add(new Tv(), 0);
		Tv tv = storage.get(0);
		System.out.printf("ù��° ��ü=%s\n", 
				              tv ) ;
//		System.out.printf("ù��° ����=%d\n", 
//				storage.get(0) ) ;
	}
}
