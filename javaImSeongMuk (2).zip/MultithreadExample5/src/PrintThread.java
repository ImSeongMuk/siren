
class PrintThread extends Thread {
    SharedArea sharedArea;
    PrintThread(SharedArea area) {   // ������
        sharedArea = area; //100���� �ּ�(������ü)
    }
    public void run() {
    	int sum =0;
    	
    	for (int cnt = 0; cnt < 3; cnt ++) {
    		//(���2)
    		sum =sharedArea.getTotal();
    		//(���1)
//    		synchronized (sharedArea) {
//    			sum = sharedArea.account1.balance + sharedArea.account2.balance;
//    		}
    		System.out.println("���� �ܾ� �հ�: " + sum);
    		try {
    			Thread.sleep(1);
    			//sharedArea.wait();
    		} catch (InterruptedException e) {
    			System.out.println(e.getMessage());
       }
    	   
       }
    }
}
