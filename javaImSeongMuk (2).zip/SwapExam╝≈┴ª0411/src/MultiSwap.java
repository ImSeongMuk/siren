public class MultiSwap<T> {//���׸�
	public void swap(T  a, T  b)
	{
		T c;
		c = a ;
		a = b;
		b = c;
		System.out.println("a="+ a + "b=" + b );
	}
}
