
public class SwapExam {

	public static void main(String[] args) {
		int  a = 3, b = 7 ;
		double  da = 3.4, db = 7.8;
		float  fa = 3.4f, fb = 7.8f;
		String  str1 = "Noodle", str2="Chicken";
		MySwap   sw = new MySwap();
		sw.iswap(a, b) ;
		sw.dswap(da, db);		
		sw.fswap(fa, fb);
		
		
		MultiSwap<Integer>  msw1 = new MultiSwap();
		MultiSwap<Double>  msw2 = new MultiSwap();
		MultiSwap<Float>  msw3 = new MultiSwap();
		msw1.swap(a, b);
		msw2.swap(da, db);
		msw3.swap(fa, fb);
	}

}
