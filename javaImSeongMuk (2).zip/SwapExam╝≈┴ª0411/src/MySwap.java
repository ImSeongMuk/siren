
public class MySwap {
	
	public void iswap(int  a, int  b)
	{
		int  c = 0 ;
		c = a ;
		a = b;
		b = c;
		System.out.println("a="+ a + "b=" + b );
	}
	public void dswap(double  a, double  b)
	{
		double  c = 0.0 ;
		c = a ;
		a = b;
		b = c;
		System.out.println("a="+ a + "b=" + b );
	}
	
	public void fswap(float  a, float  b)
	{
		float  c = 0.0f ;
		c = a ;
		a = b;
		b = c;
		System.out.println("a="+ a + "b=" + b );
	}

}
