package edu.dealim.oracle;

import java.sql.*;




public class OracelTestOne {
	Connection con;
	public OracelTestOne() {
		String url = "jdbc:oracle:thin:@localhost:1521:orcl";
		String userid = "madang";
		String pwd = "madang";
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("����̹� �ε� ����");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		try {
			System.out.println("db���� �غ�");
			con = DriverManager.getConnection(url,userid,pwd);
			System.out.println("db���� sucess");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("db ����"+e);
		}
	}
				
	private void  sqlRun(){
		String query = "select * from book";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			System.out.println("BOOK NO \tBOOK NAME \t\tPUBLISHER \tPRICE");
			while(rs.next()) {
				System.out.print("    "+rs.getInt(1)+"\t");
				System.out.print("\t"+rs.getString(2)+"\t\t");
				System.out.print(""+rs.getString(3));
				System.out.println("\t"+rs.getInt(4));
			}
			con.close();
		} catch (Exception e) {
			System.out.println("db ����"+e);
		}
	}

	public static void main(String[] args) {
		OracelTestOne so = new OracelTestOne();
		so.sqlRun();
	}

}
