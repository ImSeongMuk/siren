
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;





public class BookManagerReport extends JFrame implements ActionListener{
	
	Container con;
	Dimension  dimen, dimenOne ;
	int  xpos , ypos ;
	//�г�
	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	
	//JPanel p3 = new JPanel();
	//��
	JLabel m1 = new JLabel();
	//�ؽ�Ʈ �ʵ�
	JTextField t1 =new JTextField();
	JTextField t2 =new JTextField();
	JTextField t3 =new JTextField();
	JTextField t4 =new JTextField();
	JTextField t5 =new JTextField();
	JTextField t6 =new JTextField();
	
	//�޴� ��ư
	JButton b1 = new JButton("NEXT");
	JButton b2 = new JButton("PREVIOUS");
	
	BookDAO dao = new BookDAO();
	
	public void startUI() {
		//m1.setText("���α׷��� ���� �Ǿ����ϴ�!!");
		//m1.setEnabled(false);
		
		//7�� 1�� �ǳ� ���� 20�ȼ� ���� 2�ȼ�?
		p1.setLayout(new GridLayout(7,1));
		p2.setLayout(new GridLayout(7,1));
		
		
		JLabel l1 = new JLabel("ID");
		JLabel l2 = new JLabel("TITLE");
		JLabel l3 = new JLabel("PUBLISHER");
		JLabel l4 = new JLabel("YEAR");
		JLabel l5 = new JLabel("PRICE");
		JLabel l6 = new JLabel("���ڰ˻�");
		
		l1.setVerticalAlignment(SwingConstants.CENTER);
		l1.setHorizontalAlignment(SwingConstants.CENTER);
		l2.setVerticalAlignment(SwingConstants.CENTER);
		l2.setHorizontalAlignment(SwingConstants.CENTER);
		l3.setVerticalAlignment(SwingConstants.CENTER);
		l3.setHorizontalAlignment(SwingConstants.CENTER);
		l4.setVerticalAlignment(SwingConstants.CENTER);
		l4.setHorizontalAlignment(SwingConstants.CENTER);
		l5.setVerticalAlignment(SwingConstants.CENTER);
		l5.setHorizontalAlignment(SwingConstants.CENTER);
		l6.setVerticalAlignment(SwingConstants.CENTER);
		l6.setHorizontalAlignment(SwingConstants.CENTER);
		
		clearFiled();
		//refreshData();
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b1.setPreferredSize(new Dimension(225, 20));
		
		
		
		p1.add(l1);
		p1.add(l2);
		p1.add(l3);
		p1.add(l4);
		p1.add(l5);
		p1.add(l6);
		p1.add(b1);
	
		p2.add(t1);
		p2.add(t2);
		p2.add(t3);
		p2.add(t4);
		p2.add(t5);
		p2.add(t6);
		p2.add(b2);
		
		
		add(p1,BorderLayout.LINE_START);
		add(p2,BorderLayout.CENTER);
		
		
		
		setResizable(false);
		setVisible(true);
		
	}
	
	
	private void clearFiled() {
		t1.setText("");
		t2.setText("");
		t3.setText("");
		t4.setText("");
		t5.setText("");
		t6.setText("");
		
	}
	
	public BookManagerReport() {
		super("BOOK Application v1.0");
		setLayout(new BorderLayout(0,0));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(450,300);
		
		dimen = Toolkit.getDefaultToolkit().getScreenSize();
		dimenOne  = this.getSize() ;
		//ȭ�� �߽� ���ϱ�
		xpos  = (int) (dimen.getWidth() / 2- dimenOne.getWidth()/2);
		ypos  = (int) (dimen.getHeight() / 2- dimenOne.getHeight()/2 );		
		
		this.setLocation(xpos, ypos);		
		this.setVisible(true);//ȭ�鿡 ���̰� ����
	
	}
	
	public static void main(String[] args) {
		BookManagerReport pm = new BookManagerReport();
		pm.startUI();
		System.out.println("������");
	}
	
	String jdbcDriver = "com.mysql.cj.jdbc.Driver";
	String jdbcUrl = "jdbc:mysql://localhost:1443/bookdb?allowPublicKeyRetrieval=false&useSSL=false&serverTimezone=Asia/Seoul";
	Connection conn;
	
	PreparedStatement pstmt;
	ResultSet rs;
	
	//Vector<String> items = null;
	String sql;
	int count = 1;
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == b1) {//next�϶� ��ó������ 1�� ���̵� �����ش� �״������� 1�������Ѵ�
			if(t1.getText().equals("")) {//���̵� ���̶�
				count=1;
				connectDB();
				clearFiled();
				sql = "select * from book where book_id = 1";
				
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					System.out.println("1������");
					while(rs.next()) {
						t1.setText(rs.getString("book_id"));
						t2.setText(rs.getString("title"));
						t3.setText(rs.getString("publisher"));
						t4.setText(rs.getString("year"));
						t5.setText(rs.getString("price"));
						//datas.add(p);
						//items.add(String.valueOf(rs.getInt("prcode")));
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}finally {
					closeDB();
				}
				
			}
			else {//null�� �ƴҶ�
				connectDB();
				clearFiled();
				count = count+1;
				sql = "select * from book where book_id = "+count;
				System.out.println(sql);
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while(rs.next()) {
						t1.setText(rs.getString("book_id"));
						t2.setText(rs.getString("title"));
						t3.setText(rs.getString("publisher"));
						t4.setText(rs.getString("year"));
						t5.setText(rs.getString("price"));
						//datas.add(p);
						//items.add(String.valueOf(rs.getInt("prcode")));
					}
				} catch (SQLException e1) {
					System.out.println(e1);
					//e1.printStackTrace();
				}finally {
					closeDB();
				}
			}
		}
//		else if(obj == b2) {//����
//			if(t1.getText().equals("")) {//���̵� ���̶�
//				connectDB();
//				clearFiled();
//				try {
//					sql = "select max(book_id) FROM book;";
//					pstmt = conn.prepareStatement(sql);
//					rs = pstmt.executeQuery();
//					while(rs.next()) {
//						count =  rs.getInt("max(book_id)"); //���̺��� ���� ������ �ѹ��� �����´�.
//					}
//					
//					System.out.println("����1");
//					sql = "select * from book where book_id = " + count;
//					pstmt = conn.prepareStatement(sql);
//					rs = pstmt.executeQuery();
//					
//					System.out.println("1������");
//					while(rs.next()) {
//						t1.setText(rs.getString("book_id"));
//						t2.setText(rs.getString("title"));
//						t3.setText(rs.getString("publisher"));
//						t4.setText(rs.getString("year"));
//						t5.setText(rs.getString("price"));
//						//datas.add(p);
//						//items.add(String.valueOf(rs.getInt("prcode")));
//					}
//				} catch (SQLException e1) {
//					System.out.println(e1);
//				}finally {
//					closeDB();
//				}
//				
//			}
//			else {//null�� �ƴҶ�
//				connectDB();
//				clearFiled();
//				count = count-1;
//				sql = "select * from book where book_id = "+count;
//				System.out.println(sql);
//				try {
//					pstmt = conn.prepareStatement(sql);
//					rs = pstmt.executeQuery();
//					while(rs.next()) {
//						t1.setText(rs.getString("book_id"));
//						t2.setText(rs.getString("title"));
//						t3.setText(rs.getString("publisher"));
//						t4.setText(rs.getString("year"));
//						t5.setText(rs.getString("price"));
//						//datas.add(p);
//						//items.add(String.valueOf(rs.getInt("prcode")));
//					}
//				} catch (SQLException e1) {
//					System.out.println(e1);
//					//e1.printStackTrace();
//				}finally {
//					closeDB();
//				}
//			}
//		}
//		else if(obj == b3) {//�˻�
//			connectDB();
//			count = count-1;
//			sql = "select * FROM book where book_id = "+t1.getText();
//			clearFiled();
//			System.out.println(sql);
//			try {
//				pstmt = conn.prepareStatement(sql);
//				rs = pstmt.executeQuery();
//				while(rs.next()) {
//					t1.setText(rs.getString("book_id"));
//					t2.setText(rs.getString("title"));
//					t3.setText(rs.getString("publisher"));
//					t4.setText(rs.getString("year"));
//					t5.setText(rs.getString("price"));
//					//datas.add(p);
//					//items.add(String.valueOf(rs.getInt("prcode")));
//				}
//			} catch (SQLException e1) {
//				System.out.println(e1);
//				//e1.printStackTrace();
//			}finally {
//				closeDB();
//			}
//		}
		else if(obj == b2) {//������Ʈ
			connectDB();
			sql = "update book set "
					+ " title = '" + t2.getText()+"', "
					+ " publisher = '" + t3.getText()+"', "
					+ " year = " + t4.getText()+", "
					+ " price = " + t5.getText()
					+ " where book_id = "+t1.getText()+";";
			clearFiled();
			System.out.println(sql);
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.executeQuery();
				
				sql = "select * from book where book_id = "+count;
				
			} catch (SQLException e1) {
				System.out.println(e1);
				//e1.printStackTrace();
			}finally {
				closeDB();
			}
		}
		else if(obj == b2) {//����
			connectDB();
			sql = "delete from book where book_id ="+count;
			clearFiled();
			System.out.println(sql);
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.executeUpdate();
				
			} catch (SQLException e1) {
				System.out.println(e1);
			}finally {
				closeDB();
			}
		}
	}
	
	
	public void connectDB() {
		try {
			Class.forName(jdbcDriver);
			//conn = DriverManager.getConnection(jdbcUrl,"root","victory8");
			conn = DriverManager.getConnection(jdbcUrl,"root","daelim7!");
			} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// DB ���� ���� �޼���
	public void closeDB() {
		try {
			rs.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	
}
