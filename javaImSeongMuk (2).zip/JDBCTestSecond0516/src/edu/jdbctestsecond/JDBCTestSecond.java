package edu.jdbctestsecond;

import java.sql.*;

public class JDBCTestSecond{
	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:1443/sampledb?useSSL=false&serverTimezone=Asia/Seoul","root","daelim7!");
			//useSSL(Secure shell) ���� ��� nonon
			stmt = conn.createStatement();
			

			String sql;
			sql = "select * from student";
			rs= stmt.executeQuery(sql);
			printData(rs);
			sql ="select name,id,dept from student where name='�̱���'";
			rs = stmt.executeQuery(sql);
			printData(rs);
			
			if(conn != null) {
				System.out.println("DB ���� �Ϸ�");
				System.out.println();
			}
			
//			while (rs.next()) {
//				System.out.println(rs.getString("id"));
//				System.out.println(rs.getString("name"));
//				System.out.println(rs.getString("dept"));
//				System.out.println();
//			}
			
			
		} catch (ClassNotFoundException e) {
			System.out.println("JDBC ����̹� �ε� ����");
			
		}catch (SQLException e) {
			System.out.println(e.toString());
			System.out.println("DB ���� ����");
			
		}finally {
			try {
				conn.close();
				stmt.close();
				rs.close();
			} catch (Exception e2) {
				// TODO: handle exception
				System.out.println(e2.getMessage());
			}
		}
		
		
		
	}

	private static void printData(ResultSet rs) throws SQLException{
		// TODO Auto-generated method stub
		while(rs.next()) {
				System.out.print(rs.getString("name"));
				System.out.print("\t|"+rs.getString("id"));
				System.out.println("\t|"+rs.getString("dept"));
		}
		System.out.println();
	}

}
