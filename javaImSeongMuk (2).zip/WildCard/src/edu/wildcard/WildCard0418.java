package edu.wildcard;

import java.util.Arrays;

class Person {
    public String name;
    public Person(String name) {
        this.name = name;
    }
    public String getName() { return name; }

    @Override
    public String toString() {
        return name;
    }
}

class Student extends Person {
    public Student(String name) {
        super(name);
    }
}

class HighStudent extends Student {
    public HighStudent(String name) {
        super(name);
    }
}

class Worker extends Person {
    public Worker(String name) {
        super(name);
    }
}


public class WildCard0418 {

	public static void reginsterCourse(Course<?> course) {
		System.out.println(course.getName()+" ������ "
				+Arrays.toString(course.getStudents()));
	}
	
	public static void reginsterCourseStudent(Course<? extends Student> course) {
		System.out.println(course.getName()+" ������ "
				+Arrays.toString(course.getStudents()));
	}
	
	public static void reginsterCourseWorker(Course<? super Worker> course) {
		System.out.println(course.getName()+" ������ "
				+Arrays.toString(course.getStudents()));
	}
	
	public static void main(String[] args) {
		Course<Person> personCourse = new Course<Person>("�Ϲ��� ����", 5);
		personCourse.add(new Person("�Ϲ���"));
		personCourse.add(new Worker("������"));
		personCourse.add(new Student("�л�"));
		personCourse.add(new HighStudent("�����л�"));
		
		Course<Worker> workerCourse = new Course<Worker>("�����ΰ���", 5);
		workerCourse.add(new Worker("������"));
		
		Course<Student> studentCourse = new Course<Student>("�л�����", 5);
		studentCourse.add(new Student("�л�"));
		studentCourse.add(new HighStudent("�����л�"));
		
		Course<HighStudent> highstidentCourse = new Course<HighStudent>("�����л�����", 5);
		highstidentCourse.add(new HighStudent("�����л�"));
		
		reginsterCourse(personCourse);
		reginsterCourse(workerCourse);
		reginsterCourse(studentCourse);
		reginsterCourse(highstidentCourse);
		System.out.println();
		
		//reginsterCourseStudent(personCourse);
		//reginsterCourseStudent(workerCourse);
		reginsterCourseStudent(studentCourse);
		reginsterCourseStudent(highstidentCourse);
		System.out.println();
		
		reginsterCourseWorker(personCourse);
		reginsterCourseWorker(workerCourse);
		//reginsterCourseWorker(studentCourse);
		//reginsterCourseWorker(highstidentCourse);
		System.out.println();
		
		
		

	}

}
