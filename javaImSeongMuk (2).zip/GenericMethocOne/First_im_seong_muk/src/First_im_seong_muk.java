import java.util.Scanner;

class GuGuDan{
	int nWhile = 0;
	int nNum = 1;
	public GuGuDan() {
		// TODO Auto-generated constructor stub
		while(nWhile==0) {
			for(int j=1;j<10;j++) {
				for(int k=0;k<3;k++) {
					System.out.print(nNum+k+"*"+j+"="+(nNum+k)*j+"\t");
				}
				System.out.println();
			}
			System.out.println();
			if(nNum>6) 
				break;
			nNum=nNum+3;
		}
	}
}

public class First_im_seong_muk {
	public static void main(String[] args) {
		System.out.println("�ڹ� 3����");
		//GuGuDan DFS = new GuGuDan();//������ �ҷ�����
		 Scanner sc = new Scanner(System.in);
		 String sWord="asdasd";
		 String last = sWord.substring(sWord.length() - 1, sWord.length());			
		 System.out.println(last);

	}

}
