package edu.daelim.genericmethodone;

public class Box <T>{
	private T tob;
	public T get() {return tob;}
	public void set(T tob) {
		this.tob = tob;
	}
	
}
