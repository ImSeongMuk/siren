package edu.threadone;
//public class AlphabetThread extends Thread{

public class AlphabetThread implements Runnable{

	@Override //implements ������ 
	public void run() {
		// TODO Auto-generated method stub
		for(char i='a';i<='z';i++) {
			System.out.print(i);
		}
	}
	
//	@Override //extends ������
//	public void run() {
//		// TODO Auto-generated method stub
//		super.run();
//		for(char i='a';i<='z';i++) {
//			System.out.print(i);
//		}
//	}
	
}
