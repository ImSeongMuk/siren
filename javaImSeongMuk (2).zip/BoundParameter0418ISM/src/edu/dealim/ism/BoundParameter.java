package edu.dealim.ism;

public class BoundParameter {
	public static void main(String[] arg) {
		System.out.println("compare(10,20)ȣ��");
		int reslut1 = Util.compare(10, 20);
		System.out.println("reslut1 = "+reslut1);
		
		System.out.println("compare(4.5,3)ȣ��");
		int reslut2 = Util.compare(4.5, 3);
		System.out.println("reslut2 = "+reslut2);
		
		System.out.println("compare(100,100)ȣ��");
		int reslut3 = Util.compare(100, 100);
		System.out.println("reslut3 = "+reslut3);
	}
}
