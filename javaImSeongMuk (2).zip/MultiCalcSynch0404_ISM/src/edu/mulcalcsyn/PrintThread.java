package edu.mulcalcsyn;



class PrintThread extends Thread
{
    SharedArea sharedArea; 
    public void run() 
    {   
    	sharedArea.dd();
    }
}
