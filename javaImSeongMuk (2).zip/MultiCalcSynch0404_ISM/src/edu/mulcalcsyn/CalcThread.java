package edu.mulcalcsyn;

class CalcThread extends Thread {
	SharedArea sharedArea;
    public void run() {
    	sharedArea.calc();
    	
         
    }
}
