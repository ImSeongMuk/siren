package concave;

public class MapSize {
	private final int CELL = 30;
	private final int SIZE = 20;
	
	public int getCell(){
		return CELL;
	}
	
	public int getSize(){
		return SIZE;
	}
	
}
