import  static java.lang.System.out;

class GenEx1{
	String msg = "GenEx1";
	public String getMsg(){
		return msg;
	}
}

class GenEx2 extends GenEx1{
	String msg = "GenEx2";
	public String getMsg(){
		return msg;
	}
}

class GenEx3 extends GenEx2{
	String msg = "GenEx3";
	public String getMsg(){
		return msg;
	}
}

class GenericEx4<T>{
	T v;
	public GenericEx4(T n){
		v = n;
	}
	public void set(T n){
		v = n;
	}
	public T get(){
		return v;
	}
}


public class WildCardTypeTeachThree {
	public static void main(String[] args) {
		GenEx3 g3 = new GenEx3();
		GenericEx4<? super GenEx2> g4 = new GenericEx4<GenEx1>(g3);//super GenEx2�� �θ𿩼� Ÿ���� 
		//�ְ� �θ��� Object Ÿ���� �ȴ�?
		GenEx3 test = (GenEx3) g4.get();//g4�� T�� object�̴�
		out.println("g4 = "+test.msg+","+test.getMsg());
	}

}
