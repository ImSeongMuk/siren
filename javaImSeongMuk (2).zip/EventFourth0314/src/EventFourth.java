import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class FlowSub extends Frame
{
	Dimension  dimen, dimenOne ;
	int  xpos , ypos ;
	Button  btOK = new Button("Ȯ��") ;
	Button  btCancel = new Button("���") ;
	
	public FlowSub( ) {
		init();
		start();
		this.setSize(300, 200) ;
		//ȭ���� ũ�⸦ �����ִ� ��ƾ
		dimen = Toolkit.getDefaultToolkit().
				getScreenSize();
		dimenOne  = this.getSize() ;
		xpos  = (int) (dimen.getWidth() / 2
		       - dimenOne.getWidth()/2);
		ypos  = (int) (dimen.getHeight() / 2
	            - dimenOne.getHeight()/2 );		
		
		this.setLocation(xpos, ypos) ;		
		this.setVisible(true);
	}//end of FlowSub() 
	
	public void init()//ȭ�� ������ ���õ� �ڵ�
	{		
		FlowLayout  flow = new FlowLayout();
		this.setLayout(flow);
		
		btOK.setBackground(Color.MAGENTA);
		this.add(btOK);
		btCancel.setBackground(Color.blue);
		this.add(btCancel) ;
	}
	public void start()
	{  //event ó���� thread ���� �ڵ�
		btCancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);				
			} } ) ;
	}
}

public class EventFourth {
	public static void main(String[] args) {
		FlowSub  ob = new FlowSub() ;

	}

}
