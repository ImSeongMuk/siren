package edu.org.genericnonetype;

public class Apple {
	
}
