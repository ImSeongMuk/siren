class PrintThread extends Thread {
    SharedArea sharedArea;
    PrintThread(SharedArea area) {   // ������
        sharedArea = area;
    }
    public void run() {
   	   int  sum = 0 ;
       for (int cnt = 0; cnt < 3; cnt ++) {
    	   sum = sharedArea.getTotal() ;
//    	   synchronized( sharedArea )
//    	   {
//	           sum = sharedArea.account1.balance +
//	                     sharedArea.account2.balance;
//    	   }
            System.out.println("���� �ܾ� �հ�: " + 
                     sum);
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
