package edu.jdbstestthird;

import java.sql.*;

public class JDBCTestThird{
	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:1443/sampledb?useSSL=false&serverTimezone=Asia/Seoul","root","daelim7!");
			//useSSL(Secure shell) ���� ��� nonon
			stmt = conn.createStatement();
			String sql;
			
			sql ="insert into student(name, dept, id) values('������','��ǻ�Ͱ���','2015311');";
			stmt.executeUpdate(sql);
			
			sql ="update student set id='0189011' where name = '������';";
			stmt.executeUpdate(sql);
			
			sql ="delete from student where name ='������'";
			stmt.executeUpdate(sql);
			
			sql ="select * from student;";
			rs = stmt.executeQuery(sql);
			printData(rs);
			
			
			if(conn != null) {
				System.out.println("DB ���� �Ϸ�");
				System.out.println();
			}
			
		} catch (ClassNotFoundException e) {
			System.out.println("JDBC ����̹� �ε� ����");
			
		}catch (SQLException e) {
			System.out.println(e.toString());
			System.out.println("DB ���� ����");
			
		}finally {
			try {
				conn.close();
				stmt.close();
				rs.close();
			} catch (Exception e2) {
				// TODO: handle exception
				System.out.println(e2.getMessage());
			}
		}
		
		
		
	}


	private static void printData(ResultSet rs) throws SQLException{
		// TODO Auto-generated method stub
		while(rs.next()) {
				System.out.print(rs.getString("name"));
				System.out.print("\t|"+rs.getString("id"));
				System.out.println("\t|"+rs.getString("dept"));
		}
		System.out.println();
	}

}
