
public class MultithreadExample7 {
	public static void main(String args[]) {
        CalcThread thread1 = new CalcThread();
        PrintThread thread2 = new PrintThread();
        SharedArea obj = new SharedArea();
        thread1.sharedArea = obj;
        thread2.sharedArea = obj;
        System.out.println("thread1.start() ȣ����");
        thread1.start();
        System.out.println("thread1.start() ȣ�� ��");
        System.out.println("thread2.start() ȣ�� �� ");
        thread2.start();
        System.out.println("thread2.start() ȣ�� �� ");
    }
}
