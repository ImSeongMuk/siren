
public  class SharedArea {
	double result;
    boolean isReady;
}
