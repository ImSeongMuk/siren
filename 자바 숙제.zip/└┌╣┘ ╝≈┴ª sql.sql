create database bookdb DEFAULT character set euckr;

use bookdb;

create table book(
	book_id int NOT NULL,
	title varchar(45) NOT NULL,
    publisher varchar(45) NOT NULL,
    year int (4) NOT NULL,
    price int(11) NOT NULL,
    primary key(book_id)
)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=euckr;

insert into book(book_id, title, publisher,year,price) values(1 , 'JAVA', '홍릉과학', 2019, 2000);
insert into book(book_id, title, publisher,year,price) values(2 , '파이썬', '한빛미디어', 2018,30000);
insert into book(book_id, title, publisher,year,price) values(3 , '코틀린', '컴퓨터좋아', 2017,25000);
insert into book(book_id, title, publisher,year,price) values(4 , 'erp', '컴퓨터싫어', 2016,15000);

select * from book;